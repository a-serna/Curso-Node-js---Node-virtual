const express = require('express');
const app = express();
const path = require('path');
const hbs=require('hbs');
const bodyParser=require('body-parser');
require('./helpers');

const directoriopublico = path.join(__dirname,'../public');
const directoriopartials= path.join(__dirname, '../partials');
hbs.registerPartials(directoriopartials);
app.use(bodyParser.urlencoded({extended: false}));
app.use(express.static(directoriopublico));

app.set('view engine','hbs');

//pagina de inicio - login
app.get('/',(req,res) => {
	res.render('index',{
		estudiante: 'Sebastian'
	});
});

//pagina de registro
app.get('/registro',(req,res) => {
	res.render('registro',{
		estudiante: 'error'
	})
})

app.get('/principal',(req,res) => {
	res.render('principal')
})

//pagina de registro
app.post('/validaLogin',(req,res) => {
	res.render('validaLogin',{
		cedulau: req.body.cedulau,
		nombre: req.body.nombre
	});
});

app.post('/registra',(req,res) => {
	res.render('registra',{
		id : req.body.id,
		nombre : req.body.nombre,
		descripcion : req.body.descripcion,
		valor : req.body.valor,
		modalidad : req.body.modalidad,
		intensidad : req.body.intensidad

	});
});


//si no va a ninguna pagina conocida
app.get('*',(req,res) => {
	res.render('error',{
		Usuario: 'error'
	})
})

app.listen(3000,() => {
    console.log("escuchando en el 3000");
});